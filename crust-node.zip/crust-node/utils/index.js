/**
 * 对象数组深拷贝
 * @param {Array,Object} source 需要深拷贝的对象数组
 */
export function deepClone(source) {
  if (!source && typeof source !== 'object') {
    throw new Error('error arguments', 'deepClone')
  }
  const targetObj = source.constructor === Array ? [] : {}
  Object.keys(source).forEach(keys => {
    if (source[keys] && typeof source[keys] === 'object') {
      targetObj[keys] = deepClone(source[keys])
    } else {
      targetObj[keys] = source[keys]
    }
  })
  return targetObj
}

/**
 * 生成一个指定前缀的随机串
 * */
export  function guid(len, prefix) {
  var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
  var uuid = [], i;
  var prefixStr = prefix || '';
  let radix = chars.length;
  if (len) {
    // Compact form
    for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
  } else {
    // rfc4122, version 4 form
    var r;
    // rfc4122 requires these characters
    uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
    uuid[14] = '4';
    // Fill in random data.  At i==19 set the high bits of clock sequence as
    // per rfc4122, sec. 4.1.5
    for (i = 0; i < 36; i++) {
      if (!uuid[i]) {
        r = 0 | Math.random() * 16;
        uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
      }
    }
  }
  //附加时间撮
  var d = new Date();
  var utcId = Date.UTC(d.getFullYear()
      , d.getMonth()
      , d.getDate()
      , d.getHours()
      , d.getMinutes()
      , d.getSeconds()
      , d.getMilliseconds());
  return prefixStr + '' + utcId + uuid.join('');
}


/***
 * 根据参数匹配最合适的布局
 * @param count
 * @param maxRow
 * @param maxCol
 * @returns {*[]}
 */
export function layoutMatch(count, maxRow, maxCol) {
  var col = 1, row = 1;
  //先计算列数。
  col = Math.floor(Math.sqrt(count));
  if (col * col < count) {
    col++;
  }
  if (col > maxCol) col = maxCol
  //再计算行数。
  row = Math.floor(count / col);
  if (row * col < count) {
    row++;
  }
  if (row > maxRow) row = maxRow

  return [row, col];
}



/* eslint-disable node/no-extraneous-import */
// import {Keyring} from '@polkadot/keyring';
// import {KeyringPair} from '@polkadot/keyring/types';
// import {SubmittableExtrinsic} from '@polkadot/api/promise/types';


var Keyring=require('@polkadot/keyring')

/**
 * Send tx to crust network
 * @param krp On-chain identity
 * @param tx substrate-style tx
 * @returns tx already been sent
 */
export async function sendTx(krp, tx) {
  return new Promise((resolve, reject) => {
    tx.signAndSend(krp, ({events = [], status}) => {


      console.log(
          `  ↪ 💸 [tx]: Transaction status: ${status.type}, nonce: ${tx.nonce}`
      );

      if (
          status.isInvalid ||
          status.isDropped ||
          status.isUsurped ||
          status.isRetracted
      ) {
        reject(new Error('Invalid transaction.'));
      } else {
        // Pass it
      }

      if (status.isInBlock) {
        events.forEach(({event: {method, section}}) => {
          if (section === 'system' && method === 'ExtrinsicFailed') {
            // Error with no detail, just return error
            console.log(`  ↪ 💸 ❌ [tx]: Send transaction(${tx.type}) failed.`);
            resolve(false);
          } else if (method === 'ExtrinsicSuccess') {
            console.log(
                `  ↪ 💸 ✅ [tx]: Send transaction(${tx.type}) success.`
            );
            resolve(true);
          }
        });
      } else {
        // Pass it
      }
    }).catch(e => {
      reject(e);
    });
  });
}

/**
 * Load keyring pair with seeds
 * @param seeds Account's seeds
 */
export function loadKeyringPair(seeds) {
  const kr = new Keyring({
    type: 'sr25519',
  });

  const krp = kr.addFromUri(seeds);
  return krp;
}

export async function delay(ms) {
  return new Promise( resolve => setTimeout(resolve, ms) );
}


